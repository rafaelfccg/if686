
public class NotifyObject {
	int id;
	int cont;
	int[][] work;
	public NotifyObject() {
		cont = 0;
	}
}
